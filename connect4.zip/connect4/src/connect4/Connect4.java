

package connect4;
import java.util.Scanner;

public class Connect4 {

    //draws starting position and introduces game
    public static int[][] initBoard() {
        int height = 6;
        int width = 7;
        int[][] board = new int[height][width];
        int sum = 0;


        return board;
    }

    //prompts user for input on each turn
    public static String getInput(int[][] game) {
        Scanner in = new Scanner(System.in);
        System.out.println("Please enter a move");
        String userMove = in.nextLine();
        userMove = checkInput(userMove, game);
        userMove = checkMove(userMove, game);

        return userMove;
    }

    //checks that user input is an integer between 1 and 7
    //uses recursive functions so that user cannot continue in the program
    //until they make proper input
    public static String checkInput(String move, int[][] game) {
        int sum = 0;
        int charValue = 0;
        for(int i = 0; i < move.length(); i++) {
            char c = move.charAt(i);

            if(Character.isDigit(c)) {
                sum++;
            }
            else{
                System.out.println("Please enter an integer between 1 and 7");
                move = getInput(game);
            }
            charValue = Character.getNumericValue(c);
            if(charValue < 1 || charValue > 7){
                System.out.println("Please enter an integer between 1 and 7");
                move = getInput(game);
            }
        }
        if(sum > 1) {
            System.out.println("Please enter an integer between 1 and 7");
            move = getInput(game);
        }
        return move;
    }

    //checks that user input is a valid move on board
    public static String checkMove(String move, int[][]board) {
        int intput = Integer.parseInt(move);
        int[] column = new int[6];
        for(int i = 0; i < column.length; i++) {
            column[i] = board[i][intput-1];
        }
        for(int i = 0; i < column.length; i++) {
            if(column[i] == 0) {
                return move;
            }
        }
        move = getInput(board);
        return move;
    }

    //"four in a row" checks a string for four characters one after the 
    //other
    public static boolean fiar(String str) {
        int[] array = new int[str.length()];

        int sum1 = 0;
        int lastInt = 0;
        for(int i = 0; i < str.length(); i++){
            array[i] = Character.getNumericValue(str.charAt(i));
        }
        for(int i = 0; i < array.length; i++) {
            if(lastInt == array[i] && lastInt != 0){
                sum1++;
            }
            else{
                sum1 = 0;
            }
            lastInt = array[i];
            if(sum1 == 3){
                return true;
            }
        }
        return false;
    }

    //iterates through game board, makes a string for each possible
    //winning configuration and sends to fiar to check for win
    public static boolean checkWin(int[][]board){
        String column = "";
        String row = "";
        String diag = "";

        //check horizontal
        for(int i = 0; i < board.length; i++) {
            for(int j = 0; j < board[0].length; j++) {
                row += board[i][j];
            }
            if(fiar(row)){
                return true;
            }
            row = "";
        }

        //check vertical
        for(int i = 0; i < board[0].length; i++){
            for(int j = 0; j < board.length; j++) {
                column += board[j][i];
            }
            if(fiar(column)){
                return true;
            }
            column = "";
        }

        //check diagonal
        int k;
        for(int i = 0; i < board.length + board[0].length - 2; i++) {
            for(int j = 0; j <= i; j++){
                k = i - j;
                if(k < board.length && j < board[0].length){
                    diag += board[k][j];
                }
            }
            if(fiar(diag)){
                return true;
            }
            diag = "";

        }

        return false;
    }

    //checks each value of the game board and displays it in a more 
    //readable fashion
    public static void printBoard(int[][] board) {
        int currentMove = 0;
        for(int i = 0; i < board.length; i++) {
            for(int ii = 0; ii < board[0].length; ii++) {
                currentMove = board[i][ii];
                if(currentMove == 1) {
                    System.out.print(" X ");
                }
                else if (currentMove == 2){
                    System.out.print(" O ");
                }
                else{
                    System.out.print(" - ");
                }

            }
            System.out.println();
        }
    }


    //main game logic
    public static void main(String[] args) {

        System.out.println("This is a program designed to emulate the board game:"
        + " 'Connect 4'.\nThis is a two player game.\nTo play, please enter a number "
        + "1-7 representing the column with which you wish to place your game "
        + "piece.\nA player wins when four game tokens are placed in a row, either"
        + " horizontally, vertically, or diagonally.");

        int[][] game;
        int playerTurn;

        boolean gameState = true;
        boolean playAgain = true;
        //game loop
        while(playAgain){
            game = initBoard();
            printBoard(game);
            playerTurn = 1;
            gameState = true;

            while(gameState){


                //get input
                String move = getInput(game);

                //makes move on board

                int imove = Integer.parseInt(move);
                int[] column = new int[6];
                for(int i = 0; i < game.length; i++){
                    column[i] = game[i][imove-1];
                }
                for(int i = 0; i < column.length; i++) {
                    if(column[column.length-1-i] == 0) {
                        game[column.length-1-i][imove-1] = playerTurn;
                        if(playerTurn == 1){
                            playerTurn = 2;
                        }
                        else{
                            playerTurn = 1;
                        }
                        break;
                    }
                }


                //checks for win
                if(checkWin(game)){
                    String player = "";
                    if(playerTurn == 2) {
                        player = "Player One";
                    }
                    else{
                        player = "Player Two";
                    }

                    System.out.print(player);
                    System.out.println(",you win!");
                    gameState = false;
                }
                printBoard(game);
                System.out.println();
            }
            Scanner in = new Scanner(System.in);
            System.out.println("Type 'n' to quit or enter any other key to "
            + "play again");
            String uI = in.nextLine();

            
            if(uI.equals("n")){
                break;
            }
        }   
    }

}
